<?php
$hostname='sql107.0fees.net';
 $database='fees0_3349404_anand';
$db_username='fees0_3349404';
$db_password='andann';
/*aksid.net configration
$database='aksidco_demo';
$db_username='aksidco_demo';
$db_password='demo';*/

mysql_connect($hostname,$db_username,$db_password) or die('unable to connect db ');
mysql_select_db($database)or die('unable to select database');

$mysqlencryt='aksidsoftprivatelimited';

?>