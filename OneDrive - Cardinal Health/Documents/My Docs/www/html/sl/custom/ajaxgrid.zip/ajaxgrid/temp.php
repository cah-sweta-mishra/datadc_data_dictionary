<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">

#gallery1 {width:100%; overflow:hidden;} 
#gallery1 a {position:relative; float:left; margin:5px;} 
#gallery1 a span { display:none; background-image:url(images/favourite.png); background-repeat:no-repeat; width:48px; height:48px; position:absolute; left:15px; top:15px;} 
#gallery1 img { border: solid 1px #999; padding:5px;}
#gallery1 a:hover span { display:block;}
</style>
</head>

<body>
<div id="gallery1">
<a href="#" title="add to favourite">
        <span></span>
<img src="images/photo.png" width="100" height="100" alt="" />
    </a>
    <a href="3036302292_d37001ed77_o.jpg">
        <span></span>
        <img src="3036302292_61f44a917c_m.jpg" alt="" />
    </a>
</div>
</body>
</html>