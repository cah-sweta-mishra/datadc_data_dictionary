<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
$hostname="localhost";
$database="autoclassified";
$db_username="root";
$db_password="";
mysql_connect($hostname,$db_username,$db_password) or die("unable to connect db ");
mysql_select_db($database)or die("unable to select database");
$tablename="tbl_auto_autoclub";
$fields=array("headline","clubtype","clubname");
$addfields=array("headline","clubtype","clubname","address","person","mid","state","city","membership");
$disptext=array("headline","clubtype","clubname","address","person","mid","state","city","membership");
$fieldtype=array("TEXT","TEXT","TEXT","TEXT","TEXT","TEXT","TEXT","TEXT","TEXT");
$primarykey="clubid";
$permission=array("A","E","V","D");
$row=5;
?>