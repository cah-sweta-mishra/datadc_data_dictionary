It's created only by me
you can use it personal or it Commercial

1.just extract and goto ajaxgrid/index.php

you can customize your own wish

2. set file permission config.php 777

3. table.php is showing your table

that'a all 

share your review in greenanand@gmail.com